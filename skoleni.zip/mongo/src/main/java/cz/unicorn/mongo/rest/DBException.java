package cz.unicorn.mongo.rest;

public class DBException extends RuntimeException {
	
	public DBException(String msg) {
		super(msg);
	}

}
