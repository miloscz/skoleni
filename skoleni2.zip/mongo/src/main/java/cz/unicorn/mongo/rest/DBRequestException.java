package cz.unicorn.mongo.rest;

public class DBRequestException extends DBException{

	public DBRequestException(String msg) {
		super(msg);
	}

}
