package cz.unicorn.mongo.rest;

public class DBServerException  extends DBException {

	public DBServerException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}

}
